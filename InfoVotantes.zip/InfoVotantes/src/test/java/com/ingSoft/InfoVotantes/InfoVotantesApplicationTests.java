package com.ingSoft.InfoVotantes;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class InfoVotantesApplicationTests {

	@Test
	void contextLoads() {
	}

}
