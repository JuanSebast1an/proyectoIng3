package com.ingSoft.InfoVotantes.informes.service.serviceImpl;

public class InformeServiceImpl {
}
