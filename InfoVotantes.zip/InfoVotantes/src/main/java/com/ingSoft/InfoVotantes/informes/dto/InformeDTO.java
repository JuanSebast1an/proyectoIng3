package com.ingSoft.InfoVotantes.informes.dto;

public class InformeDTO {
}
